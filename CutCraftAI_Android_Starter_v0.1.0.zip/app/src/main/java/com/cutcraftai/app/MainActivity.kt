package com.cutcraftai.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CutCraftApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CutCraftApp() {
    var tab by remember { mutableStateOf(0) }
    var clips by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var ratio by remember { mutableStateOf("16:9") }
    var keepAudio by remember { mutableStateOf(true) }
    var lectureTitle by remember { mutableStateOf("") }
    var transcript by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var showInfo by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        clips = uris
        // Persist read permission where the provider supports it.
        uris.forEach { uri -> runCatching { } }
    }

    MaterialTheme {
        Scaffold(topBar = {
            TopAppBar(title = { Text("CutCraft AI") })
        }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
                TabRow(selectedTabIndex = tab) {
                    Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Video Editor") })
                    Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Education Studio") })
                }
                Spacer(Modifier.height(16.dp))
                if (tab == 0) {
                    Button(onClick = { picker.launch(arrayOf("video/*")) }) {
                        Text("Import video clips")
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Selected clips: ${clips.size}")
                    LazyColumn(Modifier.weight(1f)) {
                        items(clips) { uri -> Text(uri.lastPathSegment ?: uri.toString()) }
                    }
                    Text("Output aspect ratio")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("16:9", "9:16", "1:1", "4:3").forEach { item ->
                            FilterChip(selected = ratio == item, onClick = { ratio = item },
                                label = { Text(item) })
                        }
                    }
                    Row {
                        Checkbox(checked = keepAudio, onCheckedChange = { keepAudio = it })
                        Text("Keep original audio", modifier = Modifier.padding(top = 12.dp))
                    }
                    Button(onClick = { showInfo = true }, enabled = clips.isNotEmpty()) {
                        Text("Export video")
                    }
                } else {
                    OutlinedTextField(value = lectureTitle, onValueChange = { lectureTitle = it },
                        label = { Text("Lecture title") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = transcript, onValueChange = { transcript = it },
                        label = { Text("Transcript / subtitles") }, modifier = Modifier.fillMaxWidth(),
                        minLines = 5)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(value = notes, onValueChange = { notes = it },
                        label = { Text("Lecture notes") }, modifier = Modifier.fillMaxWidth(),
                        minLines = 5)
                    Text("Education Studio starter: edit and organize lecture text here.")
                }
            }
        }
        if (showInfo) {
            AlertDialog(onDismissRequest = { showInfo = false },
                title = { Text("Export not available in this starter") },
                text = { Text("This project currently imports and lists clips and provides editor settings. MP4 rendering, transitions, trimming, reordering and AI features still need to be built.") },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } })
        }
    }
}
