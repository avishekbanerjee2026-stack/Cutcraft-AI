# CutCraft AI cloud APK build package

This package lets GitHub Actions build a **debug/testing APK** without a Windows computer or Android Studio.

## Files
- `CutCraftAI_Android_Starter_v0.1.0.zip` — Android source project
- `.github/workflows/android-apk.yml` — workflow to build the APK online

## Setup from an Android tablet

1. Sign in to GitHub. Create a new repository named `CutCraftAI-Android`. For a personal test, choose **Private**.
2. In the new repository, use **Add file → Upload files** and upload `CutCraftAI_Android_Starter_v0.1.0.zip`. Commit the upload.
3. Create the workflow file:
   - Choose **Add file → Create new file**.
   - In the filename box enter `.github/workflows/android-apk.yml`.
   - Open the supplied `android-apk.yml` file from this package and copy all its contents into the GitHub editor.
   - Commit the new file to the repository's default branch.
4. Open the repository's **Actions** tab.
5. Select **Build CutCraft AI APK** in the left list.
6. Press **Run workflow**, select the default branch, then press **Run workflow** again.
7. Wait for the workflow run to finish. A green check means the build job completed.
8. Open that completed run. Find **Artifacts** near the bottom and download `CutCraft-AI-debug-APK`.
9. Extract the downloaded artifact ZIP on your tablet. It contains `app-debug.apk`.
10. Tap `app-debug.apk` to install. Android may ask you to allow your browser or file manager to install apps from that source. Only allow this for the APK you built from your own repository, then turn the permission back off after installation.

## Important
- This produces a debug APK for personal testing, not a Play Store release.
- The current starter has not been independently compiled/tested here. If the Actions run fails, open the failed run and share the error text or screenshot (hide your email and any private repository details).
- The app is still a starter: it does not yet perform real multi-clip MP4 rendering, automatic transcription/translation, voice-preserving dubbing or lip-sync.
- Do not share your GitHub password, recovery codes, access tokens, or signing keys in chat.
- Keep the repository private for a personal test. If you are under the age required to manage any account or publish an app, involve a parent/guardian and follow the service's rules.
