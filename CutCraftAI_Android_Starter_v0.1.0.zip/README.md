# CutCraft AI — Android starter (v0.1.0)

This is a native Android Studio starter project for phones and tablets.

## Included
- Video Editor and Education Studio tabs
- Multi-video file selection
- Basic output aspect-ratio choices
- Original-audio preference toggle
- Lecture title, transcript and notes fields

## Not implemented yet
- Actual multi-clip MP4 rendering/export
- Trimming, clip reordering, transitions and timeline editing
- Automatic speech-to-text, translation, voice preservation/dubbing or lip-sync
- Slide/lecture synchronization, cloud accounts, payments or publishing backend

The export action intentionally displays a message instead of pretending to render a file.

## Build
1. Install Android Studio on Windows.
2. Install Android SDK Platform 35 and JDK 17 through Android Studio.
3. Open this folder (`CutCraftAI_Android`) in Android Studio.
4. Allow Gradle sync to finish.
5. Connect an Android device with USB debugging enabled, or start an emulator.
6. Press Run.

To make a test APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

This source has not been compiled or device-tested in this environment. Resolve any Gradle or SDK errors shown by Android Studio before relying on it. For Play Store release, create a signed Android App Bundle (AAB), complete store requirements, privacy disclosures and testing. A parent/guardian should manage publishing if the developer account holder is under the applicable age requirement.
